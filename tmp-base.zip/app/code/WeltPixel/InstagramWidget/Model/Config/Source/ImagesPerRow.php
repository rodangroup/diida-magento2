<?php
namespace WeltPixel\InstagramWidget\Model\Config\Source;

class ImagesPerRow implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'col-2', 'label' => __('2')],
            ['value' => 'col-3', 'label' => __('3')],
            ['value' => 'col-4', 'label' => __('4')],
            ['value' => 'col-5', 'label' => __('5')],
            ['value' => 'col-6', 'label' => __('6')]
        ];
    }

    /**
     * Get options in "key-value" format
     *
     * @return array
     */
    public function toArray()
    {
        return [
            'col-2' => __('2'),
            'col-3' => __('3'),
            'col-4' => __('4'),
            'col-5' => __('5'),
            'col-6' => __('6')
        ];
    }
}
