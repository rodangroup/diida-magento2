var config = {
    map: {
        '*': {
            Instafeed: 'WeltPixel_InstagramWidget/js/Instafeed'
        }
    },
    shim: {
        Instafeed: {
            deps: ['jquery']
        }
    }
};