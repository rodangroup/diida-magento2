var Header = {

	headerLinks: function () {
		var headerLinks_1         = jQuery('.header.panel >.header.links'),
			headerLinks_2         = jQuery('.header_right >.header.links'),
			headerWrapper         = jQuery('.panel.wrapper'),
			headerPanel           = jQuery('.header.panel'),
			headerPanelSkip       = jQuery('.header.panel > .action.skip.contentarea'),
			headerRightMiniCart   = jQuery('.header_right > .minicart-wrapper');

		if (jQuery(window).width() >= 768){
			headerLinks_1.insertBefore(headerRightMiniCart);
			headerWrapper.hide();
		} else {
			headerLinks_2.insertAfter(headerPanelSkip);
			headerWrapper.show();
		}
	},

	resizeActions: function () {
		this.headerLinks();
	},

	action: function () {
		this.resizeActions();
	}

};

require(['jquery'],
	function ($) {
		$(document).ready(function () {
			Header.action();
		});

		$(window).load(function () {
			Header.action();
		});

		var reinitTimer;
		$(window).on('resize', function () {
			clearTimeout(reinitTimer);
			reinitTimer = setTimeout(Header.action(), 100);
		});
	}
);