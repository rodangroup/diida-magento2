<?php

namespace WeltPixel\SampleData\Model;

use Magento\Framework\Setup\SampleData\Context as SampleDataContext;

class Owl
{
    /**
     * @var \WeltPixel\OwlCarouselSlider\Model\SliderFactory
     */
    protected $sliderFactory;

    /**
     * @var \WeltPixel\OwlCarouselSlider\Model\BannerFactory
     */
    protected $bannerFactory;

    /**
     * @param \WeltPixel\OwlCarouselSlider\Model\SliderFactory $sliderFactory
     * @param \WeltPixel\OwlCarouselSlider\Model\BannerFactory
     */
    public function __construct(
        \WeltPixel\OwlCarouselSlider\Model\SliderFactory $sliderFactory,
        \WeltPixel\OwlCarouselSlider\Model\BannerFactory $bannerFactory
    ) {
        $this->sliderFactory = $sliderFactory;
        $this->bannerFactory = $bannerFactory;
    }

    public function install()
    {
        $slider = $this->sliderFactory->create();

        $sliderData = array(
            'status' => 1,
            'title' => 'Homepage V1',
            'show_title' => 0,
            'slider_content' => NULL,
            'nav' => 1,
            'dots' => 1,
            'center' => 0,
            'items' => 1,
            'loop' => 1,
            'margin' => 0,
            'merge' => 1,
            'URLhashListener' => 0,
            'startPosition' => 0,
            'stagePadding' => 0,
            'lazyLoad' => 0,
            'transition' => 'fadeOut',
            'autoplay' => 0,
            'autoplayTimeout' => 5000,
            'autoplayHoverPause' => 0,
            'autoHeight' => 0,
            'nav_brk1' => 1,
            'items_brk1' => 1,
            'nav_brk2' => 1,
            'items_brk2' => 1,
            'nav_brk3' => 1,
            'items_brk3' => 1,
            'nav_brk4' => 1,
            'items_brk4' => 1,
        );

        $slider->addData($sliderData);
        $slider->save();

        $sliderId = $slider->getData('id');

        for ($i=1; $i<5; $i++) {
            $banner = $this->bannerFactory->create();
            $bannerData = array(
                'status' => 1,
                'title'  => 'Slide ' . $i,
                'show_title'  => 0,
                'description'  => NULL,
                'show_description'  => 0,
                'banner_type'  => 1,
                'display_position'  => 1,
                'display_position'  => NULL,
                'slider_id' => $sliderId,
                'url'   => NULL,
                'target'   => '_self',
                'video'   => NULL,
                'video'   => NULL,
                'image'   => "weltpixel/owlcarouselslider/images/h/1/h1_h{$i}.jpg",
                'custom'   => NULL,
                'alt_text'  => NULL,
                'button_text'   => NULL,
                'custom_content'    => NULL,
                'valid_from'    => '2015-01-01 12:00:00',
                'valid_to' => '2030-01-01 12:00:00',
                'sort_order' => $i
            );

            $banner->addData($bannerData);
            $banner->save();

            unset($banner);
        }

        return array(
            'slider_id' => $sliderId
        );
    }
}
