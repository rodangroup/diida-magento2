var config = {
    map: {
        '*': {
            productPage: 'WeltPixel_ProductPage/js/productPage',
        }
    },
    shim: {
        productPage: {
            deps: ['jquery']
        }
    }
};