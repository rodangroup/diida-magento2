<?php

namespace WeltPixel\OwlCarouselSlider\Block\Adminhtml\Banner\Edit\Tab;

use WeltPixel\OwlCarouselSlider\Model\Status;

/**
 * Banner Edit tab.
 * @category WeltPixel
 * @package  WeltPixel_OwlCarouselSlider
 * @module   OwlCarouselSlider
 * @author   WeltPixel Developer
 */
class Banner extends \Magento\Backend\Block\Widget\Form\Generic
    implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * @var \Magento\Framework\DataObjectFactory
     */
    protected $_objectFactory;

    /**
     * slider factory.
     *
     * @var \WeltPixel\OwlCarouselSlider\Model\SliderFactory
     */
    protected $_sliderFactory;

    /**
     * @var \WeltPixel\OwlCarouselSlider\Model\Banner
     */
    protected $_bannerModel;

    /**
     * available status.
     *
     * @var \WeltPixel\OwlCarouselSlider\Model\Status
     */
    private $_status;

    /**
     * constructor.
     *
     * @param \Magento\Backend\Block\Template\Context                                  $context
     * @param \Magento\Framework\Registry                                              $registry
     * @param \Magento\Framework\Data\FormFactory                                      $formFactory
     * @param \Magento\Framework\DataObjectFactory                                     $objectFactory
     * @param \WeltPixel\OwlCarouselSlider\Model\Banner                                $banner
     * @param \WeltPixel\OwlCarouselSlider\Model\SliderFactory                         $sliderFactory
     * @param \WeltPixel\OwlCarouselSlider\Model\Status                                $status
     * @param array                                                                    $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Framework\DataObjectFactory $objectFactory,
        \WeltPixel\OwlCarouselSlider\Model\Banner $bannerModel,
        \WeltPixel\OwlCarouselSlider\Model\SliderFactory $sliderFactory,
        \WeltPixel\OwlCarouselSlider\Model\Status $status,
        array $data = []
    ) {
        parent::__construct($context, $registry, $formFactory, $data);

        $this->_objectFactory = $objectFactory;
        $this->_bannerModel   = $bannerModel;
        $this->_sliderFactory = $sliderFactory;
        $this->_status        = $status;
    }

    /**
     * prepare layout.
     *
     * @return $this
     */
    protected function _prepareLayout()
    {
        $pageTitle = $this->getPageTitle();

        $this->getLayout()->getBlock('page.title')->setPageTitle($pageTitle);

        \Magento\Framework\Data\Form::setFieldsetElementRenderer(
            $this->getLayout()->createBlock(
                'WeltPixel\OwlCarouselSlider\Block\Adminhtml\Form\Renderer\Fieldset\Element', $this->getNameInLayout()
                .'_fieldset_element'
            )
        );

        return $this;
    }

    /**
     * Prepare form.
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        $dataObj = $this->_objectFactory->create();

        /**
         * @var \WeltPixel\OwlCarouselSlider\Model\Banner $bannerModel
         */
        $bannerModel = $this->_coreRegistry->registry('banner');

        if ($sliderId = $this->getRequest()->getParam('loaded_slider_id')) {
            $bannerModel->setSliderId($sliderId);
        }

        $dataObj->addData($bannerModel->getData());

        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();

        $form->setHtmlIdPrefix($this->_bannerModel->getFormFieldHtmlIdPrefix());

        $htmlIdPrefix = $form->getHtmlIdPrefix();

        $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Banner Details')]);
        
        if ($bannerModel->getId()) {
            $fieldset->addField('id', 'hidden', ['name' => 'id']);
        }

        $elements = [];

        $elements['title'] = $fieldset->addField(
            'title',
            'text',
            [
                'name'     => 'title',
                'label'    => __('Title'),
                'title'    => __('Title'),
                'required' => true,
            ]
        );

        $elements['show_title'] = $fieldset->addField(
            'show_title',
            'select',
            [
                'name'     => 'show_title',
                'label'    => __('Show Title'),
                'title'    => __('Show Title'),
                'required' => false,
                'options'  => [
                    1 => __('Yes'),
                    0 => __('No'),
                ]
            ]
        );

        $elements['description'] = $fieldset->addField(
            'description',
            'text',
            [
                'name'     => 'description',
                'label'    => __('Description'),
                'title'    => __('Description'),
                'required' => false,
            ]
        );

        $elements['show_description'] = $fieldset->addField(
            'show_description',
            'select',
            [
                'name'     => 'show_description',
                'label'    => __('Show Description'),
                'title'    => __('Show Description'),
                'required' => false,
                'options'  => [
                    1 => __('Yes'),
                    0 => __('No'),
                ]
            ]
        );

        $elements['status'] = $fieldset->addField(
            'status',
            'select',
            [
                'label'    => __('Status'),
                'title'    => __('Banner Status'),
                'name'     => 'status',
                'required' => false,
                'options'  => $this->_status->getAllAvailableStatuses(),
            ]
        );

        $slider = $this->_sliderFactory->create()->load($sliderId);

        if ($slider->getId()) {
            $elements['slider_id'] = $fieldset->addField(
                'slider_id',
                'select',
                [
                    'label'    => __('Slider'),
                    'name'     => 'slider_id',
                    'required' => false,
                    'values'   => [
                        [
                            'value' => $slider->getId(),
                            'label' => $slider->getTitle(),
                        ],
                    ],
                ]
            );
        } else {
            $elements['slider_id'] = $fieldset->addField(
                'slider_id',
                'select',
                [
                    'label'    => __('Slider'),
                    'name'     => 'slider_id',
                    'required' => false,
                    'values'   => $bannerModel->getAvailableSliders(),
                ]
            );
        }

        $elements['url'] = $fieldset->addField(
            'url',
            'text',
            [
                'title'    => __('URL'),
                'label'    => __('URL'),
                'name'     => 'url',
                'required' => false,
            ]
        );

        $elements['target'] = $fieldset->addField(
            'target',
            'select',
            [
                'label'  => __('Target'),
                'name'   => 'target',
                'values' => [
                    [
                        'value' => '_self',
                        'label' => __('Same Window'),
                    ],
                    [
                        'value' => '_blank',
                        'label' => __('New Window Tab'),
                    ],
                ],
                'required' => false,
            ]
        );

        $elements['button_text'] = $fieldset->addField(
            'button_text',
            'text',
            [
                'title'    => __('Button Text'),
                'label'    => __('Button Text'),
                'name'     => 'button_text',
                'required' => false,
                'note'     => __('To display the button set also the URL field')
            ]
        );

        $elements['banner_type'] = $fieldset->addField(
            'banner_type',
            'select',
            [
                'label'    => __('Banner Type'),
                'name'     => 'banner_type',
                'values'   => $bannerModel->getAvailableBannerType(),
                'required' => false,
            ]
        );

        $elements['video'] = $fieldset->addField(
            'video',
            'textarea',
            [
                'title'    => __('Video'),
                'label'    => __('Video'),
                'name'     => 'video',
                'required' => false,
            ]
        );

        $elements['image'] = $fieldset->addField(
            'image',
            'image',
            [
                'title'    => __('Image'),
                'label'    => __('Image'),
                'name'     => 'image',
                'note'     => 'Allow image type: jpg, jpeg, gif, png',
                'required' => false,
            ]
        );

        $elements['custom'] = $fieldset->addField(
            'custom',
            'textarea',
            [
                'title'    => __('Custom HTML'),
                'label'    => __('Custom HTML'),
                'name'     => 'custom',
                'required' => false,
            ]
        );

        $elements['alt_text'] = $fieldset->addField(
            'alt_text',
            'text',
            [
                'title'    => __('Alt Text'),
                'label'    => __('Alt Text'),
                'name'     => 'alt_text',
                'required' => false,
            ]
        );

        if ($bannerModel->getId()) {
            $elements['bannerclass'] = $fieldset->addField(
                'bannerclass',
                'label',
                [
                    'title' => __('Banner Class'),
                    'label' => __('Banner Class'),
                    'name' => 'banner_class',
                    'value' => 'banner-' . $bannerModel->getId(),
                    'note' => __('Wrapper class for the current banner. It could be used in Custom Content to style elements on each slide individually')
                ]
            );
        }

        $elements['custom_content'] = $fieldset->addField(
            'custom_content',
            'textarea',
            [
                'title'    => __('Custom Content'),
                'label'    => __('Custom Content'),
                'name'     => 'custom_content',
                'required' => false,
            ]
        );
        
        $dateFormat = 'M/d/yyyy';
        $timeFormat = 'h:mm a';
        if ($dataObj->hasData('valid_from')) {
            $datetime = new \DateTime($dataObj->getData('valid_from'));
            $dataObj->setData('valid_from',
                $datetime->setTimezone(new \DateTimeZone($this->_localeDate->getConfigTimezone())));
        }

        if ($dataObj->hasData('valid_to')) {
            $datetime = new \DateTime($dataObj->getData('valid_to'));
            $dataObj->setData('valid_to',
                $datetime->setTimezone(new \DateTimeZone($this->_localeDate->getConfigTimezone())));
        }

        $style = 'color: #000;background-color: #fff; font-weight: bold; font-size: 13px;';
        $elements['valid_from'] = $fieldset->addField(
            'valid_from',
            'date',
            [
                'name'        => 'valid_from',
                'label'       => __('Valid From'),
                'title'       => __('Valid From'),
                'required'    => true,
                'readonly'    => true,
                'style'       => $style,
                'class'       => 'required-entry',
                'date_format' => $dateFormat,
                'time_format' => $timeFormat,
                'note'        => implode(' ', [$dateFormat, $timeFormat])
            ]
        );

        $elements['valid_to'] = $fieldset->addField(
            'valid_to',
            'date',
            [
                'name'        => 'valid_to',
                'label'       => __('Valid To'),
                'title'       => __('Valid To'),
                'required'    => true,
                'readonly'    => true,
                'style'       => $style,
                'class'       => 'required-entry',
                'date_format' => $dateFormat,
                'time_format' => $timeFormat,
                'note'        => implode(' ', [$dateFormat, $timeFormat])
            ]
        );

        $form->addValues($dataObj->getData());

        $this->setChild(
            'form_after',
            $this->getLayout()->createBlock('Magento\Backend\Block\Widget\Form\Element\Dependence')
                ->addFieldMap(
                    "{$htmlIdPrefix}banner_type",
                    'banner_type'
                )
                ->addFieldMap(
                    "{$htmlIdPrefix}video",
                    'video'
                )
                ->addFieldMap(
                    "{$htmlIdPrefix}image",
                    'image'
                )
                ->addFieldMap(
                    "{$htmlIdPrefix}custom",
                    'custom'
                )
                ->addFieldMap(
                    "{$htmlIdPrefix}alt_text",
                    'alt_text'
                )
                ->addFieldDependence(
                    'image',
                    'banner_type',
                    '1'
                )
                ->addFieldDependence(
                    'alt_text',
                    'banner_type',
                    '1'
                )
                ->addFieldDependence(
                    'video',
                    'banner_type',
                    '2'
                )
                ->addFieldDependence(
                    'custom',
                    'banner_type',
                    '3'
                )
        );

        $this->setForm($form);

        return parent::_prepareForm();
    }

    /**
     * Retrieve the banner model.
     *
     * @return \WeltPixel\OwlCarouselSlider\Model\Banner
     */
    public function getBanner()
    {
        return $this->_coreRegistry->registry('banner');
    }

    /**
     * Return the page title.
     *
     * @return \Magento\Framework\Phrase
     */
    public function getPageTitle()
    {
        return $this->getBanner()->getId()
            ? __("Edit Banner '%1'", $this->escapeHtml($this->getBanner()->getTitle())) : __('New Banner');
    }

    /**
     * Prepare tab label.
     *
     * @return string
     */
    public function getTabLabel()
    {
        return __('Banner Details');
    }

    /**
     * Prepare tab title.
     *
     * @return string
     */
    public function getTabTitle()
    {
        return __('Banner Details');
    }

    /**
     * Can show tab in tabs.
     *
     * @return boolean
     * @api
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * Tab is hidden.
     *
     * @return boolean
     * @api
     */
    public function isHidden()
    {
        return false;
    }
}
